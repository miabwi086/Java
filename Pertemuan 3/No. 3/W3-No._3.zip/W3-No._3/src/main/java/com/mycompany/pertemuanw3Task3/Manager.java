package com.mycompany.pertemuanw3Task3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Manager extends Employee {
    private String secretaryName;
    public Manager(String n, double s, int d, int m, int y) {
        super(n, s, d, m, y);
        secretaryName = "";
    }
    
    @Override
    public void raiseSalary(double byPercent) {
        java.util.GregorianCalendar todaysDate = new java.util.GregorianCalendar();
        int currentYear = todaysDate.get(java.util.Calendar.YEAR);
        
        double bonus = 0.5 * (currentYear - hireYear());
        
        super.raiseSalary(byPercent + bonus);
    }
    
    public String getSecretaryName() {
        return secretaryName;
    }
}
