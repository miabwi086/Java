package com.DuaPolymorphismViaInheritance;

/**
 *
 * @author Fatih
 */
public abstract class Shape {
    protected String shapeName;
    
    public Shape(String shapeName) {
        this.shapeName = shapeName;
    }
    
    // Tidak ada kurung kurawal karena merupakan metode abstrak
    public abstract double area(); 
    
    @Override
    public String toString() {
        return shapeName;
    }
}
