package com.pertemuan3.shapes;

/**
* The Circle class models a circle with a radius and color.
*/
public class Circle { // Save as "Circle.java"
    // private instance variable, not accessible from outside this class 
    private double radius;
    private String color;

    // Constructors (overloaded)
    /** Constructs a Circle instance with default value for radius and color */ 
    public Circle() { // 1st (default) constructor
        radius = 1.0; color = "red";
    }

    /** Constructs a Circle instance with the given radius and default color
     * @param r */ 
    public Circle(double r) { // 2nd constructor
        radius = r; 
        color = "Red";
    }

    
    public Circle(double radius, String color) { // new constructor
        this.radius = radius;
        this.color = color;
    }
    
    /** Returns the radius
     * @return  */ 
    public double getRadius() {
        return radius;
    }

    /** Returns the area of this Circle instance
     * @return  */ 
    public double getArea() {
        return radius * radius * Math.PI;
    }
    
    // ** Return color from new constructor */
    public String getColor() {
        return color;
    }
    
    public void setColor(String color, String newColor) {
        this.color = newColor;
    }

    /** * Return a self-descriptive string of this instance in the form of
    * Circle[radius=?,color=?]
     * @return 
    */  
    @Override
    public String toString() {
        return "Circle [radius = " + radius + ", color = " + color + "]";
    }
}