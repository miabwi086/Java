package id.ac.polban.employee.app;

import id.ac.polban.employee.model.*;
import id.ac.polban.employee.service.*;

public class Main {
    public static void main(String[] args) {
        
        Department itDept = new Department("IT");
        Department hrDept = new Department("HRD");
        
        EmploymentType fullTime = new EmploymentType("Full-time");
        EmploymentType contract = new EmploymentType("Contract");
        
        EmployeeService service = new EmployeeService();
        
        Employee emp1 = new Employee(1, "Budi", itDept, fullTime, 5000000);
        Employee emp2 = new Employee(1, "Ani", hrDept, contract, 4500000);
        Employee emp3 = new Employee(1, "Cici", itDept, fullTime, 7500000);

        service.addEmployee(emp1);
        service.addEmployee(emp2);
        service.addEmployee(emp3);


        System.out.println("========== Daftar Karyawan Awal ==========");
        service.displayAllEmployees();

        System.out.println("\n--- Menaikkan Gaji Karyawan ID 1 sebesar 10% ---");
        service.raiseSalary(1, 10.0);
          
        System.out.println("\n========== Daftar Karyawan Setelah Update ==========");
        service.displayAllEmployees();
        
        System.out.println("====================================================");
        
        System.out.println("\nTotal karyawan dibuat: " + Employee.getTotalCreated());
    }
}