package com.mycompany.jar;

import id.ac.polban.employee.model.*;
import id.ac.polban.employee.service.*;

public class Main {
    public static void main(String[] args) {
        Department it = new Department("IT");
        EmploymentType ft = new EmploymentType("Full-time");
        Employee emp = new Employee(1, "Budi", it, ft, 5000000);
        
        EmployeeService service = new EmployeeService();
        service.addEmployee(emp);
        service.displayAllEmployees();
    }
}