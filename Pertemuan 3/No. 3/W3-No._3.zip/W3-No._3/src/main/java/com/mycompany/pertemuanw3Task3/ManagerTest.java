package com.mycompany.pertemuanw3Task3;

import java.util.Scanner;

public class ManagerTest {
    // 1. Wajib gunakan format main method ini
    public static void main(String[] args) { 
        Scanner inputData = new Scanner(System.in);
        
        System.out.println("Masukan nama: ");
        String name = inputData.nextLine();
        
        System.out.println("Masukan gaji: ");
        double gaji = inputData.nextDouble();
        
        System.out.println("Masukan tanggal masuk: ");
        int day = inputData.nextInt();
        
        System.out.println("Masukan bulan masuk: ");
        int month = inputData.nextInt();
        
        System.out.println("Masukan tahun masuk: ");
        int year = inputData.nextInt();
        
        // 2. Buat objek SETELAH semua data input terkumpul
        // Catatan: Pastikan nama class-nya Manajer atau Manager sesuai file Anda
        Manager m1 = new Manager(name, gaji, day, month, year);
        
        // 3. Uji fungsi dari class Employee dan Manager!
        System.out.println("\n--- Data Awal ---");
        m1.print(); // Memanggil fungsi print() milik induk
        
        System.out.println("\n--- Setelah Kenaikan Gaji 5% (Plus Bonus) ---");
        m1.raiseSalary(5); // Memanggil fungsi raiseSalary() milik Manager
        m1.print(); // Cek apakah gajinya benar-benar naik plus bonus tahunan
    }
}