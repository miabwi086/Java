package com.No3;

import java.util.Scanner;

// Kelas penampung hasil akhir yang Thread-Safe
class TotalSum {
    private long total = 0;
    
    /* Synchronized mencegah Race Condition saat 
    Thread menyetorkan hasil parsialnya*/
    public synchronized void add(long partialSum) {
        total = total + partialSum;
    }
    
    public long get() {
        return total;
    }
}

// Kelas Threa yang berfungsi menghitung sebagian angka 
class SumThread extends Thread {
    private int start;
    private int end;
    private TotalSum totalSum;
    private long partialSum = 0;
    
    public SumThread(String name, int start, int end, TotalSum totalSum) {
        super(name);
        this.start = start;
        this.end = end;
        this.totalSum = totalSum;
    }
    
    @Override
    public void run() {
        // Menampilkan tugas masing-masing Thread
        System.out.println(getName() + ": Menjumlahkan angka dari " + start 
                + " sampai " + end);
        
        // Menghitung hasil parsial
        for (int i = start; i <= end; i++) {
            partialSum = partialSum + i;
        }
        
        // Menyetorkan hasil parsial ke total akhir secara aman (Thread-Safe)
        totalSum.add(partialSum);
    }
    
    // Agar hasil parsial bisa diambil oleh fungsi main
    public long getPartialSum() {
        return partialSum;
    }
}

public class PenjumlahanPararel {
    public static void main(String[] args) throws InterruptedException {
        Scanner input = new Scanner(System.in);
        
        // Menerima input
        System.out.print("Masukan Jumlah Thread: ");
        int numThreads = input.nextInt();
        
        System.out.print("Masukan Angka Terakhir: ");
        int maxNumber = input.nextInt();
        
        System.out.print("\n");

        System.out.print("--- Tugas masing-masing Thread ---\n");
        
        TotalSum totalSum = new TotalSum();
        SumThread[] threads = new SumThread[numThreads];
        
        // Mekanisme Pembagian Tugas (Divide and Conquer)
        int chunkSize = maxNumber / numThreads;
        
        // Jika pembagian bersisa, sisanya diberikan ke thread terakhir
        int remainder = maxNumber % numThreads;
        
        int currentStart = 1;
        
        // Membuat dan menjalankan thread
        for (int i = 0; i < numThreads; i++) {
            int currentEnd = currentStart + chunkSize - 1;
            
            // Thread mengambil sisa rentang angka
            if (i == numThreads - 1) {
                currentEnd = currentEnd + remainder;
            }
            
            threads[i] = new SumThread("Thread " + (i + 1), currentStart, 
                    currentEnd, totalSum);
            threads[i].start();
            
            // Titik mulai untuk thread selanjutnya
            currentStart = currentEnd + 1;
        }
        
        // Main Thread menunggu semua Thread selesai
        for (int i = 0; i < numThreads; i++) {
            threads[i].join();
        }
        
        System.out.print("\n");
        System.out.print("--- Partial masing-masing Thread ---\n");
        
        // Menampilkan hasil partial
        for(int i = 0; i < numThreads; i++) {
            System.out.println(threads[i].getName() + ": Hasil parsial = " 
                + threads[i].getPartialSum());
        }
        
        System.out.print("\n");
        
        // Tampilkan hasil akhir
        System.out.println("--- Hasil Akhir ---");
        System.out.println("Total Penjumlahan Akhir: " + totalSum.get());
        
        input.close();
    }
}
