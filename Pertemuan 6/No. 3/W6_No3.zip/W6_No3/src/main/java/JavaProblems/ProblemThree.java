package JavaProblems;

import java.util.Arrays;

public class ProblemThree {

    public static void main(String[] args) {
        int arr[] = {12, 4, 3, 1, 9, 657};
        int n = 3; // Mencari elemen terbesar ke-3
        
        // [1] Ubah array menjadi IntStream
        int ans = Arrays.stream(arr)
                // [2] Konversi ke Stream<Integer>
                .boxed()
                
                // Urutkan descending
                .sorted((a, b) -> Integer.compare(b, a))
                
                // [3] Lewati 2 elemen pertama
                .skip(n - 1)
                
                // [4] Ambil elemen yang tersisa
                .findFirst()
                
                // [5] Nilai default jika tidak ada
                .orElse(0);

        System.out.println("Elemen terbesar ke-3 adalah: " + ans);
    }
}
