package com.NoLima;

class B extends A {

    @Override
    public void displayClass() {
        System.out.println("Inside sub class B");
    }
}