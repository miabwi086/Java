package JavaProblems;

public class Employee {
    private String name;
    private int salary;
    
    // Konstruktor (Inisialisasi objek Employee)
    public Employee(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }
    
    // Getter name
    public String getName() {
        return name;
    }
    
    // Getter salary
    public int getSalary() {
        return salary;
    }
    
    @Override
    public String toString() {
        return "Employee{name='" + name + "', salary=" + salary + "}";
    }
}
