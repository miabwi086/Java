package com.NoLima;

class C extends A {

    @Override
    public void displayClass() {
        System.out.println("Inside sub class C");
    }
}