package JavaProblems;

public class Student {
    private int id;
    private String name;
    
    // Konstruktor (Inisialisasi objek Student)
    public Student(int id,String name) {
        this.id = id;
        this.name = name;
    }
    
    // Getter salary
    public int getId() {
        return id;
    }
    
    // Getter name
    public String getName() {
        return name;
    }
    
    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + "'}";
    }
}
