package com.mycompany.pertemuanw3Task2;

public class ShapeTest {
    public static void main(String[] args) {
        // Menguji Shape Dasar
        Shape basicShape = new Shape("red", false);
        System.out.println("1. SHAPE:");
        System.out.println(basicShape.toString());
        System.out.println();

        // Menguji Circle
        Circle circle = new Circle(7.0, "blue", true);
        System.out.println("2. CIRCLE:");
        System.out.println(circle.toString());
        System.out.println("Area Circle: " + circle.getArea());
        System.out.println("Perimeter Circle: " + circle.getPerimeter());
        System.out.println();

        // Menguji Rectangle
        Rectangle rectangle = new Rectangle(5.0, 10.0, "yellow", false);
        System.out.println("3. RECTANGLE:");
        System.out.println(rectangle.toString());
        System.out.println("Area Rectangle: " + rectangle.getArea());
        System.out.println("Perimeter Rectangle: " + rectangle.getPerimeter());
        System.out.println();

        // Menguji Square
        Square square = new Square(4.0, "purple", true);
        System.out.println("4. SQUARE:");
        System.out.println(square.toString());
        System.out.println("Area Square: " + square.getArea());
        System.out.println("Perimeter Square: " + square.getPerimeter());
        
        // Menguji validasi sisi Square
        square.setLength(8.0); // Hanya mengubah length
        System.out.println("\nSetelah sisi (length) diubah jadi 8.0:");
        System.out.println("Width juga ikut berubah: " + square.getWidth());
        System.out.println("Luas baru: " + square.getArea());
    }
}