package com.TigaPolymorphicSorting;

import java.util.Scanner;

/**
 *
 * @author Fatih
 */
public class Strings {
    // --------------------------------------------
    // Reads in an array of Strings, sorts them,
    // then prints them in sorted order.
    // --------------------------------------------
    
    public static void main (String[] args) {
        String[] stringList;
        int size;
        Scanner scan = new Scanner(System.in);
        
        System.out.print("\nHow many strings do you want to sort? ");
        size = scan.nextInt();
        
        stringList = new String[size];
        
        System.out.println("\nEnter the strings (words)...");
        for (int i = 0; i < size; i++) {
            stringList[i] = scan.next();
        }
        
        Sorting.insertionSort(stringList);
        
        System.out.println("\nYour strings in sorted order...");
        for (int i = 0; i < size; i++) {
            System.out.print(stringList[i] + " ");
        }
        System.out.println();
    }
}
