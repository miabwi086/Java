package com.p2p.domain;

import java.math.BigDecimal;

public class Borrower {
    private boolean verified;
    private int creditScore;
    private BigDecimal balance;
    
    /**
     *
     * @param verified
     * @param creditScore
     * @return 
     */
    
    // =========================
    // DOMAIN BEHAVIOR
    // =========================
    public boolean canApplyLoan() {
        return this.verified;
    }
    
    public Borrower(boolean verified, int creditScore) {
        this.verified = verified;
        this.creditScore = creditScore;
    }
    
    public boolean isVerified() {
        return verified;
    }
    
    public int getCreditScore() {
        return creditScore;
    }
    
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public void pay(BigDecimal amount){
        this.balance = this.balance.subtract(amount);
    }
}
