package com.p2p.domain;

import java.math.BigDecimal;

public class Lender {
    private BigDecimal balance;
    
    public void Lender(BigDecimal balance) {
        this.balance = balance;
    }
    
    public BigDecimal getBalance() {
        return balance;
    }
    
    public void withdraw(BigDecimal amount) {
        this.balance = this.balance.subtract(amount);
    }
    
    public Lender(BigDecimal balance) {
        this.balance = balance;
    }
}