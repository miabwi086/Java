package com.SatuPolymorphismViaInheritance;

/**
 *
 * @author Fatih
 */
public class Commission extends Hourly {
    private double totalSales;
    private double commissionRate;
    
    // Constructor 6 variabel
    public Commission(String eName, String eAddress, String ePhone, 
            String socSecNumber, double rate, double commissionRate) {
        // 5 parameter pertama ke class induk (Hourly)
        super(eName, eAddress, ePhone, socSecNumber, rate);
        
        // Parameter terakhir ke class sendiri
        this.commissionRate = commissionRate;
        
        // Mengatur nilai awal total penjualan menjadi 0
        this.totalSales = 0.0;
    }
    
    public void addSales (double totalSales) {
        this.totalSales = this.totalSales + totalSales;
    }
    
    /**
     *
     * @return
     */
    @Override
    public double pay() {
        // Memanggil metode pay() milik Hourly
        double hourlyPay = super.pay();
        
        // Menghitung komisi penjualan
        double commissionPay = totalSales * commissionRate;
        
        // Reset penjualan menjadi 0 untuk periode gaji berikutnya
        totalSales = 0.0;
        
        return hourlyPay + commissionPay;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        // Mengambil teks informasi dasar dari class induk
        String result = super.toString();
        
        result = result + "\nTotal Sales: "+ totalSales;
        
        return result;
    }
}
