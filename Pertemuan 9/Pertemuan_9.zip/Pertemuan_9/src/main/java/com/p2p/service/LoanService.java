package com.p2p.service;

import com.p2p.domain.Borrower;
import com.p2p.domain.Lender;
import com.p2p.domain.Loan;
import java.math.BigDecimal;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoanService {
    private static final Logger logger = LogManager.getLogger(com.p2p.service.LoanService.class);        

    public Loan createLoan(Borrower borrower, BigDecimal amount) {
        // Log info saat proses dimulai
        logger.info("Memulai proses pembuatan pinjaman dengan nominal: " + amount);
        
        // Validasi untuk TC-03 dan TC-04
        
        // =========================
        // CREATE LOAN (domain object)
        // =========================
        Loan loan = new Loan();
        loan.setAmount(amount);
        
        validateApplication(borrower, amount);
        
        // =========================
        // BUSINESS ACTION (domain behavior)
        // =========================
        if (borrower.getCreditScore() >= 599) {
            loan.approve();
            logger.info("Pinjaman disetujui untuk borrower dengan credit score: " + borrower.getCreditScore());
        } else {
            loan.reject();
            logger.warn("Pinjaman ditolak! Credit score terlalu rendah: " + borrower.getCreditScore());
        }
        
        return loan;
    }
    
    public void fundLoan(Loan loan, Lender lender, BigDecimal fundAmount){
        if(lender.getBalance().compareTo(fundAmount) < 0) {
            throw new IllegalArgumentException("Balance not enough");
        }
        lender.withdraw(fundAmount);
         
        // Logika TC-07: Jika didanai penuh, status menjadi FUNDED
        if(fundAmount.compareTo(loan.getAmount()) >= 0) {
            loan.markAsFunded();
        }
    }
    
    public void disburseLoan(Loan loan) {
        if(!"FUNDED".equals(loan.getStatus())) {
            throw new IllegalStateException("Loan must be FUNDED before disbursement");
        }
        loan.setStatus("ACTIVE");
    }
    
    public void repayLoan(Loan loan, Borrower borrower){
        if(!"ACTIVE".equals(loan.getStatus())) {
            throw new IllegalStateException("Only active loans can be repaid");
        }
        
        if (borrower.getBalance().compareTo(loan.getAmount()) < 0) {
            throw new IllegalStateException("Borrower balance not enough for repayment");
        }
        
        borrower.pay(loan.getAmount());
        loan.setStatus("PAID");
    }
    
    // =========================
    // PRIVATE VALIDATION METHOD
    // =========================
    private void validateBorrower(Borrower borrower) {
        if (!borrower.canApplyLoan()) {
            throw new IllegalArgumentException("Borrower not verified");
        }
    }
    
    private void validateApplication(Borrower borrower, BigDecimal amount) {
        if (!borrower.canApplyLoan()) {
            logger.error("Validasi gagal: Borrower belum diverifikasi (KYC)");
            throw new IllegalArgumentException("Borrower not verified");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            logger.error("Validasi gagal: Nominal pinjaman tidak valid (" + amount + ")");
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
    }
}