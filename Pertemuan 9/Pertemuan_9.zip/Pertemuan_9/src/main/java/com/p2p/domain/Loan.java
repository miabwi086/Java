package com.p2p.domain;

import java.math.BigDecimal;

public class Loan {
    private String status; // Jika: Approved, Rejected, atau Funded
    private BigDecimal amount;
    
    public Loan() {
        
    }
    
    public Loan(String status) {
        this.status = status;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    // =========================
    // DOMAIN BEHAVIOR
    // =========================
    public void approve() {
        this.status = "APPROVED"; 
    }
    
    public void reject() {
        this.status = "REJECTED";
    }
}
