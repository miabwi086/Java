package com.mycompany.pertemuanw3Task3;

public abstract class Sortable {
    public abstract int compare(Sortable b);
    
    // Logika Algoritma Pengurutan (Shell Sort)
    public static void shell_sort(Sortable[] a) {
        int n = a.length;
        
        // Membagi array menjadi beberapa jarak (gap)
        for (int gap = n / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < n; i++) {
                Sortable temp = a[i];
                int j;

                for (j = i; j >= gap && a[j - gap].compare(temp) > 0; j -= gap) {
                    a[j] = a[j - gap];
                }
                
                a[j] = temp;
            }
        }
    }
}
