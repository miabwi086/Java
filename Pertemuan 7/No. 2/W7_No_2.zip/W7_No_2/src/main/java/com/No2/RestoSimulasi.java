package com.No2;

class Resto {
    private int chickenStock = 100;
    
    /* Menambahkan synchronized agar hanya ada 1 Thread yang bisa menjalankan
       method ini diwaktu yang sama*/
    public synchronized void serveCustomer(String cashierName) {
        if (chickenStock > 0) {
            
            /* Simulasi waktu mengambil ayam */
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
            
            }
            
            chickenStock--; 
            System.out.println(cashierName + " berhasil menjual 1 ayam\n. "
                    + "Sisa stok: " + chickenStock + "\n");
        } else {
            System.out.println(cashierName + " gagal: Stok Habis!");
        }
    }

    public int getRemainingStock() {
        return chickenStock;
    }
}

public class RestoSimulasi {
    public static void main(String[] args) throws InterruptedException {
        Resto ayamJuicyLuicyGallagher = new Resto();
        
        /* Setiap Thread berusaha untuk menjual 40 ayam */ 
        Runnable task = () -> {
            for (int i = 0; i < 40; i++) {
                ayamJuicyLuicyGallagher.serveCustomer(Thread.currentThread().getName());
            }
        };

        Thread kasir1 = new Thread(task, "Kasir-A");
        Thread kasir2 = new Thread(task, "Kasir-B");
        Thread kasir3 = new Thread(task, "Kasir-C");

        kasir1.start();
        kasir2.start();
        kasir3.start();

        kasir1.join();
        kasir2.join();
        kasir3.join();
        
        System.out.println("\n");
        System.out.println("--- HASIL AKHIR STOK: " + 
                ayamJuicyLuicyGallagher.getRemainingStock() + " ---");
    }
}
