package com.pertemuan3.shapes;

public class MainCircle {
    public static void MainCircle (String[] args) {

    // New Cylinder
    Cylinder c = new Cylinder(5.0, "Blue", 10.0); 
    System.out.println("Cylinder:"
    + " radius = " + c.getRadius()
    + " height = " + c.getHeight()
    + " base area = " + c.getArea()
    + " volume = " + c.getVolume());
    }
}
