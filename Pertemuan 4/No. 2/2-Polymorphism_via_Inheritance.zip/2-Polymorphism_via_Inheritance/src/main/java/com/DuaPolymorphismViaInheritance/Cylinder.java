package com.DuaPolymorphismViaInheritance;

/**
 *
 * @author Fatih
 */
public class Cylinder extends Shape {
    // Deklarasi khusus untuk silinder
    private double radius;
    private double height;
    
    public Cylinder(double r, double h) {
        super("Cylinder");
        
        radius = r;
        height = h;
    }
    
    /**
     *
     * @return
     */
    @Override
    public double area() {
        return Math.PI * radius * radius * height;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString() + " of radius" + radius + " and height " + height;
    }
}
