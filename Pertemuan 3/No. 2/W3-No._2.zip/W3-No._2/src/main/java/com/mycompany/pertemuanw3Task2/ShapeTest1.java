package com.mycompany.pertemuanw3Task2;

public class ShapeTest1 {
    public static void main(String[] args) {
        // Menguji Constructor tanpa argumen (Default)
        Shape shape1 = new Shape();
        System.out.println("--- Menguji Constructor Default ---");
        System.out.println(shape1.toString()); // Output: A Shape with color of green and filled
        System.out.println("Warna (dari getter): " + shape1.getColor());
        System.out.println("Filled (dari getter): " + shape1.isFilled());

        // Menguji Constructor dengan argumen
        Shape shape2 = new Shape("blue", false);
        System.out.println("\n--- Menguji Constructor dengan Argumen ---");
        System.out.println(shape2.toString()); // Output: A Shape with color of blue and Not filled

        // Menguji Setter (mengubah nilai)
        System.out.println("\n--- Menguji Setter ---");
        shape2.setColor("yellow");
        shape2.setFilled(true);
        System.out.println("Setelah diubah: " + shape2.toString()); // Output: A Shape with color of yellow and filled
    }
}