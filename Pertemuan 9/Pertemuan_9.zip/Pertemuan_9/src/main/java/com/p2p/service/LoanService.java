package com.p2p.service;

import com.p2p.domain.Borrower;
import com.p2p.domain.Lender;
import com.p2p.domain.Loan;
import java.math.BigDecimal;

public class LoanService {
    public Loan createLoan(Borrower borrower, BigDecimal amount) {
        
        // =========================
        // VALIDASI (delegasi ke domain)
        // =========================
        validateBorrower(borrower);

        // Validasi untuk TC-01
        if (!borrower.isVerified()) {
            throw new IllegalArgumentException("Borrower not verified");
        }
        
        // Validasi untuk TC-02
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero");
        }
        
        // Validasi untuk TC-03 dan TC-04
        
        // =========================
        // CREATE LOAN (domain object)
        // =========================
        Loan loan = new Loan();
        
        // =========================
        // BUSINESS ACTION (domain behavior)
        // =========================
        if (borrower.getCreditScore() >= 600) {
            loan.setStatus("APPROVED");
        } else {
            loan.setStatus("REJECTED");
        }
        
        return loan;
    }
    
    public void fundLoan(Loan loan, Lender lender, BigDecimal fundAmount){
        if(lender.getBalance().compareTo(fundAmount) < 0) {
            throw new IllegalArgumentException("Balance not enough");
        }
        lender.withdraw(fundAmount);
         
        // Logika TC-07: Jika didanai penuh, status menjadi FUNDED
        if(fundAmount.compareTo(loan.getAmount()) >= 0) {
            loan.setStatus("FUNDED");
        }
    }
    
    public void disburseLoan(Loan loan) {
        if(!"FUNDED".equals(loan.getStatus())) {
            throw new IllegalStateException("Loan must be FUNDED before disbursement");
        }
        loan.setStatus("ACTIVE");
    }
    
    public void repayLoan(Loan loan, Borrower borrower){
        if(!"ACTIVE".equals(loan.getStatus())) {
            throw new IllegalStateException("Only active loans can be repaid");
        }
        
        if (borrower.getBalance().compareTo(loan.getAmount()) < 0) {
            throw new IllegalStateException("Borrower balance not enough for repayment");
        }
        
        borrower.pay(loan.getAmount());
        loan.setStatus("PAID");
    }
    
    // =========================
    // PRIVATE VALIDATION METHOD
    // =========================
    private void validateBorrower(Borrower borrower) {
        if (!borrower.canApplyLoan()) {
            throw new IllegalArgumentException("Borrower not verified");
        }
    }
}