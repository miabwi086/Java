package com.p2p.service;

import com.p2p.domain.Borrower;
import com.p2p.domain.Loan;
import com.p2p.domain.Lender;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

public class LoanServiceTest {
    private LoanService service;
    
    @BeforeEach
    void setUp() {
        service = new LoanService();
    }
    
    @Test
    void shouldRejectLoanWhenBorrowerNotVerified() {
        // Arrange
        // Buat Borrower yang belum terverifikasi (false)
        Borrower borrower = new Borrower(false, 700);
        
        // Act & Assert
        // Harusnya menghasilkan IllegalArgumentException
        assertThrows(IllegalArgumentException.class, () -> {
            service.createLoan(borrower, BigDecimal.valueOf(1000));
        });
    }
    
    @Test
    void shouldRejectLoanWhenAmountIsZeroOrNegative() {
        Borrower borrower = new Borrower(true, 700);
        
        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.createLoan(borrower, BigDecimal.ZERO);
        });
    }
    
    @Test
    void shouldApproveLoanWhenCreditScoreHigh() {
        Borrower borrower = new Borrower(true, 700);
        
        // Act
        Loan loan = service.createLoan(borrower, BigDecimal.valueOf(1000));
        
        // Assert
        assertEquals("APPROVED", loan.getStatus());
    }
    
    @Test
    void shouldApproveLoanWhenCreditScoreLow() {
        Borrower borrower = new Borrower(true, 699);
        
        // Act
        Loan loan = service.createLoan(borrower, BigDecimal.valueOf(1000));
        
        // Assert
        assertEquals("APPROVED", loan.getStatus());
    }
    
    @Test
    void shouldAllowFundingWhenBalanceSufficient() {
        Loan loan = new Loan("APPROVED");
        
        loan.setAmount(BigDecimal.valueOf(1000));
        // Lender dengan saldo 2000 (Cukup untuk mendanai 1000)
        Lender lender = new Lender(BigDecimal.valueOf(2000));

        // Act
        service.fundLoan(loan, lender, BigDecimal.valueOf(1000));

        // Assert
        assertEquals(BigDecimal.valueOf(1000), lender.getBalance());
    }

    @Test
    void shouldRejectFundingWhenBalanceNotEnough() {
        Loan loan = new Loan("APPROVED");
        
        loan.setAmount(BigDecimal.valueOf(1000));
        // Lender dengan saldo 500 (Kurang)
        Lender lender = new Lender(BigDecimal.valueOf(500));

        // Act & Assert
        assertThrows(IllegalArgumentException.class, () -> {
            service.fundLoan(loan, lender, BigDecimal.valueOf(1000));
        });
    }
    
    @Test
    void shouldMarkLoanAsFundedWhenFullyFunded() {
        Loan loan = new Loan("APPROVED");
        loan.setAmount(BigDecimal.valueOf(1000));
        Lender lender = new Lender(BigDecimal.valueOf(1000));

        // Act
        service.fundLoan(loan, lender, BigDecimal.valueOf(1000));

        // Assert
        assertEquals("FUNDED", loan.getStatus());
    }
    
    @Test
    void shouldNotActivateLoanIfNotFunded() {
        // Loan baru dengan status APPROVED, bukan FUNDED
        Loan loan = new Loan("APPROVED");
        
        // Act & Assert
        assertThrows(IllegalStateException.class, () -> {
            service.disburseLoan(loan);
        });
    }

    @Test
    void shouldActivateLoanWhenFunded() {
        // Loan yang sudah terkumpul dananya
        Loan loan = new Loan("FUNDED");
        
        // Act
        service.disburseLoan(loan);
        
        // Assert
        assertEquals("ACTIVE", loan.getStatus());
    }
    
    @Test
    void shouldAllowRepaymentWhenLoanActive() {
        Loan loan = new Loan("ACTIVE");
        loan.setAmount(BigDecimal.valueOf(1000));
        
        // Borrower dengan saldo 1500 untuk membayar pinjaman 1000
        Borrower borrower = new Borrower(true, 700);
        borrower.setBalance(BigDecimal.valueOf(1500));

        // Act
        service.repayLoan(loan, borrower);

        // Assert
        // Saldo akhir harusnya 1500 - 1000 = 500
        assertEquals(BigDecimal.valueOf(500), borrower.getBalance());
        assertEquals("PAID", loan.getStatus());
    }
}