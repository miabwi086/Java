package TestJARTask2;

// Kita bisa melakukan import ini KARENA file JAR sudah berhasil dimasukkan!
import id.ac.polban.employee.model.Department;
import id.ac.polban.employee.model.EmploymentType;
import id.ac.polban.employee.model.Employee;

public class TestJARTask2 {
    public static void main(String[] args) {
        System.out.println("=== MENGUJI FILE JAR ===");
        
        // Memanggil kelas dari dalam JAR
        Department dpt = new Department("Keuangan");
        EmploymentType type = new EmploymentType("Tetap");
        
        // Membuktikan Static ID juga terbawa dan berfungsi
        Employee pegawaiBaru = new Employee("Siti", dpt, type, 6000000);
        
        System.out.println("Nama   : " + pegawaiBaru.getName());
        System.out.println("Dept   : " + pegawaiBaru.getDepartment().getName());
        System.out.println("Status : " + pegawaiBaru.getType().getType());
        System.out.println("Berhasil memanggil fungsi dari file JAR!");
    }
}