package com.mycompany.pertemuanw3Task2; // Sesuaikan dengan nama package Anda

public class Shape {
    // Deklarasi variabel
    private String color;
    private boolean filled;

    // 1. Constructor No-arg (Default)
    public Shape() {
        color = "green";
        filled = true;
    }

    // 2. Constructor berparameter
    public Shape(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }

    // --- Getter & Setter ---
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    @Override
    public String toString() {
        String isItFilled = "";
        if (filled == true) {
            isItFilled = "filled";
        } else {
            isItFilled = "Not filled";
        }
        
        return "A Shape with color of " + color + " and " + isItFilled;
    }
}