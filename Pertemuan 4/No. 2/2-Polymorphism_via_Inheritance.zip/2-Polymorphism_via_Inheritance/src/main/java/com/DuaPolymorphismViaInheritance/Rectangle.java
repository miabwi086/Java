package com.DuaPolymorphismViaInheritance;

/**
 *
 * @author Fatih
 */
public class Rectangle extends Shape {
    // Deklarasi variabel khusus persegi panjang 
    private double length;
    private double width;
    
    public Rectangle(double l, double w) {
        // Mengirimkan nama bangun ke Shape.java
        super("Rectangle");
        
        // Menyimpan nilai panjang dan lebar
        length = l;
        width = w;
    }
    
    /**
     *
     * @return
     */
    @Override
    public double area() {
        return length * width;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString() + " of length " + length + " and width " + width; 
    }
}