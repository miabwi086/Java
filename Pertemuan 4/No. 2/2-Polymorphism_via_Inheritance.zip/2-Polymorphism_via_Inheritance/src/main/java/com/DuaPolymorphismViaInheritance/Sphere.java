package com.DuaPolymorphismViaInheritance;

/* 
*****************************************
Sphere.java

Represents a sphere.
*****************************************
*/

public class Sphere extends Shape {
    private double radius; //radius in feet
    
    //----------------------------------
    // Constructor: Sets up the sphere.
    //----------------------------------
 
    public Sphere(double r) {
        super("Sphere");
        radius = r;
    }
    
    //-----------------------------------------
    // Returns the surface area of the sphere.
    //-----------------------------------------

    /**
     *
     * @return
     */
    @Override
    public double area() {
        return 4 * Math.PI * radius * radius;
    } 

    //-----------------------------------
    // Returns the sphere as a String.
    //-----------------------------------

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString() + " of radius " + radius;
    }
} 