package JavaProblems;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ProblemTwo {

    public static void main(String[] args) {
        List<Student> students = Arrays.asList(
                new Student(101, "Joe"),
                new Student(103, "Zulkifli"),
                new Student(102, "Riza"),
                new Student(104, "Alice"),
                new Student(105, "Joshua")
        );
        
        // Melakukan proses filtering/sorting menggunakan Stream API
        List<Student> ans = students.stream() // [1] Membuka stream
                .sorted((s1, s2) -> {        // [2] Melakukan pengurutan
                    
                    /* Jika nama sama, bandingkan ID. 
                       Jika nama berbeda, bandingkan nama */
                    if(s1.getName().equalsIgnoreCase(s2.getName())) {
                        // [3] Membandingkan ID
                        return Integer.compare(s1.getId(), s2.getId()); 
                    } else {
                       // [4] Membandingkan nama abaikan case
                       return s1.getName().compareToIgnoreCase(s2.getName());
                    }
                })
        .collect( Collectors.toList() ); // [5] Mengumpulkan hasil akhir
        
        for(Student student : ans){
            System.out.println(student);
        }
    }
}
