package com.mycompany.pertemuanw3Task3;

public class Employee extends Sortable {
    private String name;
    private double salary;
    private int day;
    private int month;
    private int year;

    public Employee(String n, double s, int d, int m, int y) {
        this.name = n;
        this.salary = s;
        this.day = d;
        this.month = m;
        this.year = y;
    }
    
    public void raiseSalary(double byPercent) {
        this.salary = salary * (1 + byPercent / 100);
    }
    
    public void print() {
        System.out.println(name + " " + salary + " " + day + " " + month + " " + year + " ");
    }
    
    public int hireYear() {
        return year;
    }
    
    /**
     *
     * @param b
     * @return
     */
    @Override
    public int compare(Sortable b) {
    // Ubah (casting) 'b' menjadi Employee untuk membaca gaji
    Employee eb = (Employee) b;
    
    if (this.salary < eb.salary) {
        return -1;
    } 
    
    if (this.salary > eb.salary) {
        return 1;
    } 
    return 0;
    }
}