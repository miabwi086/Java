package com.No1;

class Account {
    int balance = 150;
}

public class TransferFulus {
    public static void main(String[] args) throws InterruptedException {
        Account acc1 = new Account();
        Account acc2 = new Account();

        // Thread 1: Menjumlahkan/ transfer fulus dari acc1 ke acc2
        Thread t1 = new Thread(() -> {
            synchronized (acc1) { // Mengunci acc1
                System.out.println("Thread1: Mengunci acc1, persiapan transfer ke acc2");
                try {
                    Thread.sleep(100); 
                } catch (Exception e) {
                    
                } /* Exception diperlukan untuk menghindari Deadlock, 
                    dimana 2 thread menunggu resource yang dipegan thread lain. 
                    Membuat tidak ada satupun thread yang bisa melanjutkan proses */

                synchronized (acc2) { // Mengunci acc2
                    System.out.println("Thread1: Mengunci acc2, Melakukan transfer...\n");
                    acc2.balance += acc1.balance;
                }
            }
        });

        // Thread 2: Menjumlahkan/ transfer fulus dari acc2 ke acc1
        Thread t2 = new Thread(() -> {
            synchronized (acc1) { // Mengunci acc1 aga urutan sama dengan Thread1
                System.out.println("Thread2: Mengunci acc1, persiapan transfer ke acc1");
                try {
                    Thread.sleep(100);
                } catch (Exception e) {
                
                }

                synchronized (acc2) { // Mengunci acc2
                    System.out.println("Thread2: Mengunci acc1, Melakukan transfer...\n");
                    acc1.balance += acc2.balance;
                }
            }
        });

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("---- HASIL AKHIR ----\n");
        System.out.println("Saldo Akhir acc1: " + acc1.balance);
		System.out.println("Saldo Akhir acc2: " + acc2.balance);
    }
}