package id.ac.polban.employee.model;

public class Employee {
    private int id;
    private String name;
    private Department department;
    private EmploymentType type;
    private double salary;
    private static int idCounter = 1;
    
    public static int getTotalCreated() {
        return idCounter - 1;
    }
    
    public Employee(int par, String name, Department department, EmploymentType type, double salary) {
        this.id = idCounter++;
        this.name = name;
        this.department = department;
        this.type = type;
        this.salary = salary;
    }

    public Employee(String string, Department it, EmploymentType ft, double d) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
 
    public String getName() {
        return name;
    }
 
    public void setName(String name) {
        this.name = name;
    }
    
    public Department getDepartment() {
        return department;
    }
    
    public void setDepartment(Department department) {
        this.department = department;
    }
    
    public EmploymentType getType() {
        return type;
    }
    
    public void setType(EmploymentType type) {
        this.type = type;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
}