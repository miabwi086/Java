package com.pertemuan3.shapes;

public class Cylinder extends Circle { // Save as "Cylinder.java" 
    private double height; // private variable

    // Constructor with default color, radius and height 
    public Cylinder(double radius, String color) {
        super(radius, color); // call superclass no-arg constructor Circle() 
        this.height = 1.0;
    }

    // Constructor with default radius, color but given height 
    public Cylinder(double height) {
        super(); // call superclass no-arg constructor Circle() 
        this.height = height;
    }

    // Constructor with default color, but given radius, height 
    public Cylinder(double radius, String color, double height) {
        super(radius, color); // call superclass constructor Circle(radius) 
        this.height = height;
    }

    // A public method for retrieving the height
    public double getHeight() { 
        return height;
    }

    // A public method for computing the volume of cylinder
    // use superclass method getArea() to get the base area 
    public double getVolume() {
        return super.getArea() * height;
    }
    
    /**
     *
     * @return
     */
    @Override
    public double getArea() {
        return (2 * super.getArea()) + (2 * Math.PI * getRadius() * height);
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Cylinder: subclass of" + super.toString() + " height = " + height;
    }
}