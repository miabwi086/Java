package com.mycompany.pertemuanw3Task3;

public class EmployeeTest {
    public static void main(String[] args) {
        // Mendeklarasikan dan mengalokasikan array untuk 3 objek Employee 
        Employee[] staff = new Employee[3];

        // Inisialisasi data karyawan
        staff[0] = new Employee("Isabel Vidal ", 6250000, 1, 10, 1989);
        staff[1] = new Employee("Maria Bianchi", 1500000, 1, 12, 1991);
        staff[2] = new Employee("Antonio Rossi", 3700000, 1, 11, 1993);
    
        // Menaikkan gaji setiap staf sebesar 5% 
        for (int i = 0; i < 3; i++) {
            staff[i].raiseSalary(5);
        }

        // Mencetak data dari setiap staf 
        for (int i = 0; i < 3; i++) {
            staff[i].print();
        }
        
        Sortable.shell_sort(staff);
        
        System.out.println("\n--- Setelah Diurutkan (Berdasarkan Gaji) ---");
        for (int i = 0; i < staff.length; i++) {
            staff[i].print();
        }
    }
}

